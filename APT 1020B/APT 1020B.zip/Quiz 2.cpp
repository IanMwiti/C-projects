#include <stdio.h>
using namespace std;
int main()
{
    int x;
    cout<<"Input the values for x and y: \n";
    cin>>x;
    if (x == y){
        cout<<"x and y are equal\n";
    }
    else if (x>y){
        cout<<"x is greater than y\n";
    }
    else if (x<y){
    	cout<<"x is greater than y\n";
	}
	else {
		cout<<"Invalid";
	}
    

}
