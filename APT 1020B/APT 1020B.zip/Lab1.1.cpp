#include<iostream>
using namespace std;
int main()
{
cout<<"*******Welcome to Kenya cities"<<endl;
cout<<"1.Nairobi"<<endl;
cout<<"2.Mombasa"<<endl;
cout<<"3.Kisumu"<<endl;
return 0;
}
