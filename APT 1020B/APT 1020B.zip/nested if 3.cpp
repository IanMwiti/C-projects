#include <iostream>
using namespace std;
int main() {
	// local variable declaration
	int x;
	cout<<"enter grade\n";
	cin>>x;
	if (x==1){
	cout<<"x is 1";
	}
	else if (x==2){
		cout<<"x is2";
	}
	else{
	cout<<"value of x unknown";
}
}

