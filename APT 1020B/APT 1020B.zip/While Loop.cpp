#include <iostream>
using namespace std;
int main()
{
	int i;
	cout<<"Enter a Number"<<endl;
	cin>>i;
	while (i<5){
		cout<<i<<endl;
		i++;
	}
	return 0;
	}

