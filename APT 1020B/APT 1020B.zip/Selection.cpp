#include <iostream>
using namespace std;
int main()
{
	int age;
	cout<<"Enter Age"<<endl;
	cin>>age;
	if(age<30){
		cout<<"Go back home\n";
			}
	else {cout<<"Karibu Member\n";
	}
}	
