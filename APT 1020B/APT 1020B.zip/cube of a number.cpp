#include <iostream>
using namespace std;
int main(){
int x;
cout<<"Enter the number"<<endl;
cin>>x;
int cube;
cube=x*x*x;
cout<<"The Cube is "<<cube<<endl;
return 0;
}
