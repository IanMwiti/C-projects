#include <iostream>
using namespace std;
int main() {
	//local variable declaration
	char x;
	cout<<"Enter Grade\n";
	cin>>x;
	if (x==1){
		cout<<"x is 1";
	}
	else if (x==2){
		cout<<"x is 2";
	}
	cout<<"value of x unknown";
}

